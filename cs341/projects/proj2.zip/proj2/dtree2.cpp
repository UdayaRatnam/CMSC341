/**
 * CMSC 341 - Spring 2021
 * Project 2 - Binary Trees
 * DiscriminatorTree.cpp
 * Implementation for the DTree class.
 */

#include "dtree2.h"

/**
 * Destructor, deletes all dynamic memory.
 */
DTree::~DTree() {
    //clear(this->_root);
    //delete this->_root;
    /**
    delete this->_root;
    this->_root = nullptr;
    **/
    clear();
}
void DTree::deleteTree(DNode* node){
    if(node == nullptr){
        //cout<<"detectsnull condition"<<endl;
        return;
    }
    deleteTree(node->_left);
    deleteTree(node->_right);
    //cout<<node<<". "<<node->_left<<", "<<node->_right<<endl;
    //cout<<"right here"<<endl;
    delete node;
    node = nullptr;
}
void DTree::recursiveCopy(DNode* srcNode, DNode*& copyNode){
    if(srcNode == nullptr){
        return;
    }
    //insert(node->getAccount());
    copyNode = new DNode(srcNode->getAccount());
    copyNode->_size = srcNode->_size;
    copyNode->_numVacant = srcNode->_numVacant;
    copyNode->_vacant = srcNode->_vacant;
    recursiveCopy(srcNode->_left,copyNode->_left);
    recursiveCopy(srcNode->_right,copyNode->_right);
}
/**
 * Overloaded assignment operator, makes a deep copy of a DTree.
 * @param rhs Source DTree to copy
 * @return Deep copy of rhs
 */
DTree& DTree::operator=(const DTree& rhs) {
    cout<<"Overloaded assignment operator, makes a deep copy of a DTree."<<endl;   
    if(this != &rhs){
        cout<<"entered condition"<<endl;
        this->clear();
        recursiveCopy(rhs._root, this->_root);
    }
    return *this;
}

/**
 * Dynamically allocates a new DNode in the tree. 
 * Should also update heights and detect imbalances in the traversal path
 * an insertion.
 * @param newAcct Account object to be contained within the new DNode
 * @return true if the account was inserted, false otherwise
 */
bool DTree::insert(Account newAcct) {
    
    return recursiveInsert(this->_root, newAcct,false);
}


bool DTree::recursiveInsert(DNode*& localRoot, Account acct, bool isCreated){
    if(localRoot == nullptr){
        localRoot = new DNode (acct);
        isCreated = true;
        updateSize(localRoot);
        updateNumVacant(localRoot);
    }
    else if(localRoot->isVacant()){
        cout<<"found vacant node"<<endl;
        if(retrieve(acct.getDiscriminator()) == nullptr){
            if(localRoot->_left->getDiscriminator() < acct.getDiscriminator() && localRoot->_right->getDiscriminator() > acct.getDiscriminator()){
                localRoot = new DNode(acct);
                localRoot->_vacant = false;
                localRoot->_numVacant -= 1;
                return true;
            }
        }
    }
    else if(acct.getDiscriminator() < localRoot -> getDiscriminator()){
        isCreated = recursiveInsert(localRoot->_left, acct, isCreated);
    }
    else if(acct.getDiscriminator() > localRoot->getDiscriminator()){
        isCreated = recursiveInsert(localRoot->_right, acct, isCreated);
    }
    else{
        isCreated = false;
    }
   
   
    if(checkImbalance(localRoot)){
        cout<<"DTREE SIZE "<<localRoot->getSize()<<"(Imbalance at localRoot " <<localRoot->getDiscriminator()<<"), "<<endl;
        rebalance(localRoot);
       
    }
    
    return isCreated;  
}

DNode* DTree::recursiveRemove(DNode* node, int disc){
    return nullptr;
}
/**
 * Removes the specified DNode from the tree.
 * @param disc discriminator to match
 * @param removed DNode object to hold removed account
 * @return true if an account was removed, false otherwise
 */
bool DTree::remove(int disc, DNode*& removed) {

    return false;
}
DNode* DTree::recursiveSearch(DNode* node, int disc){
    if(node != nullptr){
        if(node->getDiscriminator() == disc){
            return node;
        }
        else{
            DNode* temp = recursiveSearch(node->_left, disc);
            if(temp == nullptr){
                temp = recursiveSearch(node->_right, disc);
            }
            return temp;
        }
    }
    else{
        return nullptr;
    }
}
/**
 * Retrieves the specified Account within a DNode.
 * @param disc discriminator int to search for
 * @return DNode with a matching discriminator, nullptr otherwise
 */
DNode* DTree::retrieve(int disc) {

    return recursiveSearch(this->_root, disc);
    
}

/**
 * Helper for the destructor to clear dynamic memory.
 */
void DTree::clear() {
    //cout<<"clear function riught herew"<<endl;
    deleteTree(this->_root);
    this->_root = nullptr;
    
    //cout<<"helps clear dynamic memory in destructor"<<endl;

}

/**
 * Prints all accounts' details within the DTree.
 */
void DTree::printAccounts() const {

    cout<<"prints all accounts details within DTree"<<endl;
}

/**
 * Dump the DTree in the '()' notation.
 */
void DTree::dump(DNode* node) const {
    if(node == nullptr) return;
    cout << "(";
    dump(node->_left);
    cout << node->getAccount().getDiscriminator()<< ":" << node->getSize() << ":" << node->getNumVacant();
    dump(node->_right);
    cout << ")";
}



/**
 * Returns the number of valid users in the tree.
 * @return number of non-vacant nodes
 */
int DTree::getNumUsers() const {
    return 0;
}

/**
 * Updates the size of a node based on the imedaite children's sizes
 * @param node DNode object in which the size will be updated
 */
void DTree::updateSize(DNode* node){
    
    DNode* temp = this->_root;
    while(temp != node){
        if(node->getDiscriminator() < temp->getDiscriminator()){
            temp->_size++;
            temp = temp->_left;
        }
        else{
            temp->_size++;
            temp = temp ->_right;
            
        }

    }
    
    //cout<<"Updates size of a node based on the imediate childrens sizes"<<endl;
    
}


/**
 * Updates the number of vacant nodes in a node's subtree based on the immediate children
 * @param node DNode object in which the number of vacant nodes in the subtree will be updated
 */
void DTree::updateNumVacant(DNode* node) {

    DNode* temp = this->_root;
    while(temp != node){
        if(node->getDiscriminator() < temp->getDiscriminator()){
            temp = temp ->_left;
            if(temp->isVacant()){
                temp->_numVacant++;
            }
        }
        else{
            
            temp = temp->_right;
            if(temp->isVacant()){
                temp->_numVacant++;
            }
        }
        
    }
    //cout<<"Updates the number of vacant nodes in a node's subtree based on the immediate children"<<endl;
}

/**
 * Checks for an imbalance, defined by 'Discord' rules, at the specified node.
 * @param checkImbalance DNode object to inspect for an imbalance
 * @return (can change) returns true if an imbalance occured, false otherwise
 */
bool DTree::checkImbalance(DNode* node) {
   
     
    int leftSize = 0;   
    int rightSize = 0;
    if(node->_left != nullptr){
        leftSize = node->_left->getSize(); 
    }
    if(node->_right != nullptr){
        rightSize = node->_right->getSize();
    }
    
    if(leftSize >= 4 || rightSize >= 4){
        if(leftSize >= (rightSize * 1.5) || rightSize >= (leftSize * 1.5)){
            //cout<<"disc: "<<node->getDiscriminator()<< ", Left: "<<node->_left->getSize()<<" Right: "<<node->_right->getSize()<<endl;
            return true;
        }
    }
    return false;
    
}

//----------------
/**
 * Begins and manages the rebalancing process for a 'Discrd' tree (pass by reference).
 * @param node DNode root of the subtree to balance
 */
void DTree::rebalance(DNode*& node) {

    cout<<"Begins and manages the rebalancing process for a 'Discrd' tree (pass by reference)."<<endl;
    storeDNodes(node);
}

void DTree::traversal(DNode* node, int* index, Account *accountArray){
    //if(node == nullptr) return nullptr;
    if(node == nullptr) {
        return;
    }

    traversal(node->_left, index, accountArray);
    accountArray[*index] =  node->getAccount();
    ++*index;
    traversal(node->_right, index, accountArray);
}

void DTree::storeDNodes(DNode* node){

    Account* discArray = new Account[node->getSize()];
    int i = 0;
    traversal(node, &i, discArray);
    for (i = 0; i < node->getSize(); i++) cout << "Value: " << discArray[i] << endl;

    cout << "END" << endl;
    DTree rdtree;
    int midpoint = node->getSize() / 2;
    rdtree.insert(discArray[midpoint]);
    cout<<discArray[midpoint]<<endl;
    for(i = 0; i < node->getSize(); i++) {
        if (i != midpoint) {
            rdtree.insert(discArray[i]);
        }
    }
    //*this = rdtree;
    cout<<"hello"<<endl;
    rdtree.dump();
    delete [] discArray;

}
// -- OR --

/**
 * Begins and manages the rebalancing process for a 'Discrd' tree (returns a pointer).
 * @param node DNode root of the subtree to balance
 * @return DNode root of the balanced subtree
 */
//DNode* DTree::rebalance(DNode*& node) {
    
//}
//----------------

/**
 * Overloaded << operator for an Account to print out the account details
 * @param sout ostream object
 * @param acct Account objec to print
 * @return ostream object containing stream of account details
 */
ostream& operator<<(ostream& sout, const Account& acct) {
    sout << "Account name: " << acct.getUsername() << 
            "\n\tDiscriminator: " << acct.getDiscriminator() <<
            "\n\tNitro: " << acct.hasNitro() << 
            "\n\tBadge: " << acct.getBadge() << 
            "\n\tStatus: " << acct.getStatus();
    return sout;
}